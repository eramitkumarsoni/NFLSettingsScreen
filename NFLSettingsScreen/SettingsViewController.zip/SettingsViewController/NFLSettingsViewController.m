//
//  NFLSettingsViewController.m
//  NFLSettingsScreen
//
//  Created by Avadesh Yadav on 10/29/13.
//  Copyright (c) 2013 Strumsoft. All rights reserved.
//

#define colorWithRGB(R,G,B) [UIColor colorWithRed:R/255.0 green:G/255.0 blue:B/255.0  alpha:1.0]

#import "NFLSettingsViewController.h"

@interface NFLSettingsViewController () <UITableViewDataSource, UITableViewDelegate>

@property (weak, nonatomic) IBOutlet UITableView *settingsTableView;
@property (strong, nonatomic) NSArray *tableDataSource;
@end

@implementation NFLSettingsViewController

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self doInitializations];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Private Methods
- (void)doInitializations
{
    self.tableDataSource = @[@{@" " : @[@"Sign In", @"Bengals"]},
                             @{@"CONNECT SOCIAL": @[@"Connect to Facebook"]},
                             @{@"SUBSCIPTIONS": @[@"Mobile Premium", @"Restore Purchases"]},
                             @{@"VIDEO":@[@"Closed Captioning"]},
                             @{@"HELP": @[@"FAQs"]},
                             @{@"MORE": @[@"Privacy Policy", @"Terms & Conditions", @"Send Feedback", @"Rate NFL Mobile"]},
                             @{@"APP INFO": @[@"NFL Version:1.0.1.0", @"Ref Id:526f7d810cf237aa2fb0675f"]}];
    
    [self.settingsTableView setDataSource:self];
    [self.settingsTableView setDelegate:self];
}

- (UISwitch *)getSwitchForVideoAccessoryView
{
    UISwitch *switchAccessory = [[UISwitch alloc] init];
    [switchAccessory addTarget:self action:@selector(didChangedValueForVideoSwitch:) forControlEvents:UIControlEventValueChanged];
    
    return switchAccessory;
}

- (void)didChangedValueForVideoSwitch:(UISwitch *)sender
{
    if ([sender isOn]) {
        NSLog(@"Turned On");
    }
    else {
        NSLog(@"Turned Off");
    }
}

- (void)configureCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSDictionary *dictDetails = [self.tableDataSource objectAtIndex:[indexPath section]];
    NSString *headerTitle = [[dictDetails allKeys] lastObject];
    NSString *textForCell = [dictDetails[headerTitle] objectAtIndex:[indexPath row]];
    [cell.textLabel setText:textForCell];
    
    if ([headerTitle isEqualToString:@"CONNECT SOCIAL"]) {
        [cell.imageView setImage:[UIImage imageNamed:@"facebookIcon.png"]];
    }
    else if ([headerTitle isEqualToString:@"SUBSCIPTIONS"]) {
        [cell.imageView setImage:[UIImage imageNamed:@"PlayButtonIcon.png"]];
    }
    else if ([headerTitle isEqualToString:@"VIDEO"]) {
        [cell setAccessoryView:[self getSwitchForVideoAccessoryView]];
    }
    else if ([headerTitle isEqualToString:@" "]) { // Top First one Without header
      
        if ([indexPath row] == 0) {
            [cell.imageView setImage:[UIImage imageNamed:@"NFL_Logo.png"]];
        }
        else {
            [cell.imageView setImage:[UIImage imageNamed:@"teamLogo.png"]];

        }
        
    }
    
    if ([headerTitle isEqualToString:@"MORE"] || [headerTitle isEqualToString:@"HELP"] || [headerTitle isEqualToString:@"SUBSCIPTIONS"] || [headerTitle isEqualToString:@" "]) {
        [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    }
    
    [cell.textLabel setTextColor:colorWithRGB(44.0, 44.0, 44.0)];
}

#pragma mark - UITableView DataSource and Delegate Methods
- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSDictionary *dictDetails = [self.tableDataSource objectAtIndex:section];
    NSString *keyForHeader = [[dictDetails allKeys] lastObject];
   
   return [dictDetails[keyForHeader] count];
}

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    return [self.tableDataSource count];
}

- (UIView *) tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0) {
        return nil;
    }
    
    UIView *headerView = [[UIView alloc] initWithFrame:CGRectMake(0, 0, tableView.bounds.size.width, 30)];
    [headerView setBackgroundColor:colorWithRGB(103.0, 103.0, 103.0)];
    
    CGRect headingLabelFrame = headerView.frame;
    headingLabelFrame.origin.x = 10;
    UILabel *headingLabel = [[UILabel alloc] initWithFrame:headingLabelFrame];
    [headingLabel setTextAlignment:NSTextAlignmentLeft];
    [headingLabel setText:[[self.tableDataSource[section] allKeys] lastObject]];
    [headingLabel setTextColor:[UIColor whiteColor]];
    [headingLabel setFont:[UIFont boldSystemFontOfSize:17.0f]];
    
    [headerView addSubview:headingLabel];
    
    return headerView;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    float heightForSection = 0;
    
    if (section != 0) {
        heightForSection = 30;
    }
    
    return heightForSection;
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    UITableViewCell *cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:@"settingsCell"];
    [self configureCell:cell forRowAtIndexPath:indexPath];
    
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSLog(@"TableView Row Selected at RowIndex:%d in Section:%d", [indexPath row], [indexPath section]);
}

@end
