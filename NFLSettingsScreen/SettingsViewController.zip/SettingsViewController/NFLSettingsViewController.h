//
//  NFLSettingsViewController.h
//  NFLSettingsScreen
//
//  Created by Avadesh Yadav on 10/29/13.
//  Copyright (c) 2013 Strumsoft. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface NFLSettingsViewController : UIViewController

@end
